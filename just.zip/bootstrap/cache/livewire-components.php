<?php return array (
  'appointment-table' => 'App\\Http\\Livewire\\AppointmentTable',
  'city-locality-dropdown' => 'App\\Http\\Livewire\\CityLocalityDropdown',
  'connection-table' => 'App\\Http\\Livewire\\ConnectionTable',
  'delete-appointment' => 'App\\Http\\Livewire\\DeleteAppointment',
  'delete-connection' => 'App\\Http\\Livewire\\DeleteConnection',
  'delete-doctor' => 'App\\Http\\Livewire\\DeleteDoctor',
  'delete-patient' => 'App\\Http\\Livewire\\DeletePatient',
  'delete-ummah' => 'App\\Http\\Livewire\\DeleteUmmah',
  'doctor-table' => 'App\\Http\\Livewire\\DoctorTable',
  'patient-table' => 'App\\Http\\Livewire\\PatientTable',
  'response-table' => 'App\\Http\\Livewire\\ResponseTable',
  'ummah-table' => 'App\\Http\\Livewire\\UmmahTable',
);